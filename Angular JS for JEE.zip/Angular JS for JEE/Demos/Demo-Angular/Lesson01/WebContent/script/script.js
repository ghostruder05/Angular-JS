

//Creating a module
var productName = angular.module('productDetail',[]);

//Creating A Controller & Registering with Module
productName.controller('ProductController',function($scope){
	
	
	
	$scope.product={
			'id': 1001,
			'name': 'Book',
			'price': 380
	};});
//Creating A Controller & Registering with Module
productName.controller('MessageController', function($scope) {
	//attaching SIMPLE
	$scope.message='Hello Angular ......';
});
//Creating A Controller & Registering with Module
productName.controller('EmployeeController', function($scope) {
	//attaching Simple
	$scope.employeeId=1001,
	$scope.employeeName='Rahul Vikash'
	
});