/**
 * Go To Console in Google Chrome & Check Scope is printed 
 */

var sample =angular.module('Injectorexample',[]);

var injector=angular.injector(['Injectorexample','ng']);

var scope= injector.get('$rootScope');
console.log(scope);

/**
 *  This we will discuss   in Lesson 4 
 */
sample.factory("product", function () {
	  return {
	    name: "Book"
	  };
	});
sample.controller("AppCtrl", function ($scope, $injector) {
	  $injector.invoke(function (product) {
	    alert(product.name);
	    $scope.name = product.name;
	  });
	});